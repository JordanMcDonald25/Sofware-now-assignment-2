import pandas as pd
import os
import glob

folder = "temperatures"
files = glob.glob(os.path.join(folder, "*.csv"))

print("search for csv files in:", os.path.abspath(folder))
print("Found files:", files)

def get_season(month):
    if month in [12, 1, 2]:
        return "summer"
    elif month in [3, 4, 5]:
        return "autumn"
    elif month in [6, 7, 8]:
        return "winter"
    elif month in [9, 10, 11]:
        return "spring"
    
month_map = {
    "January": 1, "February": 2, "March": 3, "April": 4,
    "May": 5, "June": 6, "July": 7, "August": 8,
    "September": 9, "October": 10, "November": 11, "December": 12

}

all_data = []
for file in files:
    print(f"\n Reading file: {files}")
    df = pd.read_csv(file)

    year = None
    basename = os.path.basename(file)
    for token in basename.replace(".", "_").split("_"):
        if token.isdigit():
            year = int(token)
            break 

    df_melted = df.melt(
        id_vars=["STATION_NAME", "STN_ID", "LAT", "LON"],
        var_name="MonthName",
        value_name="Temperature"
    )
    

    df_melted["Month"] = df_melted["MonthName"].map(month_map)
    df_melted["Year"] = year
    df_melted["season"] = df_melted["Month"].apply(get_season)

    all_data.append(df_melted)

if not all_data:
    print("No usable csv files found.")
    exit()

data_melted = pd.concat(all_data, ignore_index=True)
print("\n Combine data shape:", data_melted.shape)
print("Columns:", data_melted.columns.tolist())
print("Sample data:\n", data_melted.head(), "\n")

season_avg = data_melted.groupby('season')['Temperature'].mean()

with open("average_temp.txt", "w") as f:
    for season in ['summer', 'autumn', 'winter', 'spring']:
        if season in season_avg:
            f.write(f"{season}: {season_avg[season]:.1f}°C\n")

station_stats = data_melted.groupby('STATION_NAME')['Temperature'].agg(['max', 'min'])
station_stats['Range'] = station_stats['max'] - station_stats['min']
max_range = station_stats['Range'].max()
largest_range_station = station_stats[station_stats['Range'] == max_range]

with open("largest_temp_range_stations.txt", "w") as f:
    for idx, row in largest_range_station.iterrows():
        f.write(f"Station {idx}: Range {row['Range']:.1f}°C"
                f"(Max: {row['max']:.1f}°C, Min: {row['min']:.1f}°C\n")
                


station_std = data_melted.groupby('STATION_NAME')['Temperature'].std()
min_std = station_std.min()
max_std = station_std.max()
most_stable = station_std[station_std == min_std]
most_variable = station_std[station_std == max_std]

with open("temperature_stability_stations.txt", "w") as f:
    for idx, val in most_stable.items():
        f.write(f"Most Stable: Station {idx}: StdDev {val:.1f}°C\n")
    for idx, val in most_variable.items():
        f.write(f"Most Variable: Station {idx}: stdDev {val:.1f}°C\n")

print("\n Analysis complete. Results saved as:")
print(" - average_temp.txt")
print(" - largest_temp_range_stations.txt")
print(" - temperature_stability_stations.txt")